import Layout from "./Layout"
const Dashboard = ()=>{
    return (
        <Layout>
            <div>
                sdfsd
            </div>
        </Layout>
    )
}

export default Dashboard