import Layout from "./Layout"

const Settings = ()=>{
    return (
        <Layout>
            <div>
                sdfsd
            </div>
        </Layout>
    )
}

export default Settings